class Session {
    init() {
        let sess = {
            secret: 'f9883422eb49321744ee3e1e8297af3451e8d812887d0e39fbe9b1960ac98b6b',
            cookie: {},
            saveUninitialized: false,
            resave: false
        }
        return sess
    }

    setUser(req, userName) {
        req.session.user = userName
    }

    getUser(req) {
        return req.session.user
    }

    resetUser(req) {
        req.session.user = null
    }
}

module.exports = Session